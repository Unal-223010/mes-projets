class Seat (private var busy: Boolean,
            var row: Char,
            var column : Int) {

}
