object TheaterApplication extends App {

  var newTheater : Theater = new Theater(5, 10)
  print(newTheater.getSeat(0, 0))







}