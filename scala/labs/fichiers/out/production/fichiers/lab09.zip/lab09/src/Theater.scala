class Theater(var size_y: Int,
              var size_x: Int) {

  val tab : Array[Array[Seat]] = Array.ofDim[Seat](size_y, size_x)

  for (row <- tab.indices) {
    for (column <- tab(row).indices) {
      var x: Char  = (row + 'a').toChar
      // to test: println (s"$x$column")
      tab(row)(column) = new Seat(false, x , column)
    }
  }
  def getSeat(row: Int, column: Int): Seat  = {
    return tab(row)(column)
  }
}

